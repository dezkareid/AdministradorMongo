 var map;
 var selector=null;
 var seleccionDestino=null;
 var markers;
 var ultimo=null;

function onEachFeature(feature, layer) {
            var popupContent = feature.properties.NOM_ESTAB;
            layer.bindPopup(popupContent);
}

function init(){
   map = L.map('map');
    var osmUrl='http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    var osmAttrib='Map data © openstreetmap contributors';
    var osm = new L.TileLayer(osmUrl,{minZoom:2,maxZoom:18,attribution:osmAttrib});
    map.setView(new L.LatLng(19.540649,-96.926408),13);
    map.addLayer(osm);
  
    markers=new Array(dependencias.features.lenght);
    var miniIndice=0;
    var baseballIcon = L.icon({
            iconUrl: 'uv_e.png',
            iconSize: [60, 40],
            iconAnchor: [16, 37],
            popupAnchor: [0, -28]
        });

    var googleLayer = new L.Google('ROADMAP');
      map.addLayer(googleLayer);
    var DLayer = L.geoJson(dependencias, {

            pointToLayer: function (feature) {
                var marker= L.marker([feature.geometry.coordinates[1],feature.geometry.coordinates[0]], {icon: baseballIcon});
                marker.on('mouseover', function(e){
                marker.openPopup();});
                marker.on('mouseout', function(e){
                marker.closePopup();});
                markers[miniIndice]=marker;
                miniIndice++;
                return marker;
            },
            onEachFeature: onEachFeature
        });

    map.addLayer(DLayer);
    var baseLayers = {
            "Base": osm, "Google": googleLayer
        };

    var overlays = {
            "dependencias": DLayer
        };

        L.control.layers(baseLayers, overlays).addTo(map);

        loadComboOrigen();
}

function loadComboOrigen(){
    $("<option value='"+"'>Selecciona una opcion</option>").appendTo("#origen");
    for(feat in dependencias.features){
        $("<option value='"+feat+"'>"+dependencias.features[feat].properties.NOM_ESTAB+"</option>").appendTo("#origen");
    }
    autoCompleta();
}

function colorear(indice){

    if(selector!=null){
        selector.setLatLng(  new L.LatLng(dependencias.features[indice].geometry.coordinates[1],dependencias.features[indice].geometry.coordinates[0]) );
    }
    else{
        selector=    L.circle([dependencias.features[indice].geometry.coordinates[1],dependencias.features[indice].geometry.coordinates[0]], 100, {
            color: 'red',
            fillColor: '#f03',
            fillOpacity: 0.5
        });
    selector.addTo(map);
}
 markers[indice].openPopup();

}

function llenaComboDestino(index){
    $("#destino").empty();
    $("<option value='"+"'>Selecciona una opcion</option>").appendTo("#destino");
    for(feat in dependencias.features){
        if (feat == index)
            continue;
        $("<option value='"+feat+"'>"+dependencias.features[feat].properties.NOM_ESTAB+"</option>").appendTo("#destino");
  }

    
    autoCompleta2();

}
function colorear2(indice){

if(seleccionDestino  !=null){
        seleccionDestino.setLatLng(  new L.LatLng(dependencias.features[indice].geometry.coordinates[1],dependencias.features[indice].geometry.coordinates[0]) );
    
    
    }else{
    seleccionDestino =    L.circle([dependencias.features[indice].geometry.coordinates[1],dependencias.features[indice].geometry.coordinates[0]], 100, {
            color: 'blue',
            fillColor: '#f03',
            fillOpacity: 0.5
        });
    seleccionDestino.addTo(map);
}
 markers[indice].openPopup();

}

function autoCompleta2(){
(function( $ ) {
        $.widget( "ui.combobox", {
            _create: function() {
                var input,
                    that = this,
                    select = this.element.hide(),
                    selected = select.children( ":selected" ),
                    value = selected.val() ? selected.text() : "",
                    wrapper = this.wrapper = $( "<span>" )
                        .addClass( "ui-combobox" )
                        .insertAfter( select );

                function removeIfInvalid(element) {
                    var value = $( element ).val(),
                        matcher = new RegExp( "^" + $.ui.autocomplete.escapeRegex( value ) + "$", "i" ),
                        valid = false;
                    select.children( "option" ).each(function() {
                        if ( $( this ).text().match( matcher ) ) {
                            this.selected = valid = true;
                            return false;
                        }
                    });
                    if ( !valid ) {
                        // remove invalid value, as it didn't match anything
                        $( element )
                            .val( "" )
                            .attr( "title", value + " didn't match any item" )
                            .tooltip( "open" );
                        select.val( "" );
                        setTimeout(function() {
                            input.tooltip( "close" ).attr( "title", "" );
                        }, 2500 );
                        input.data( "autocomplete" ).term = "";
                        return false;
                    }
                }

                input = $( "<input>" )
                    .appendTo( wrapper )
                    .val( value )
                    .attr( "title", "" )
                    .addClass( "ui-state-default ui-combobox-input" )
                    .autocomplete({
                        delay: 0,
                        minLength: 0,
                        source: function( request, response ) {
                            var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
                            response( select.children( "option" ).map(function() {
                                var text = $( this ).text();
                                if ( this.value && ( !request.term || matcher.test(text) ) )
                                    return {
                                        label: text.replace(
                                            new RegExp(
                                                "(?![^&;]+;)(?!<[^<>]*)(" +
                                                $.ui.autocomplete.escapeRegex(request.term) +
                                                ")(?![^<>]*>)(?![^&;]+;)", "gi"
                                            ), "<strong>$1</strong>" ),
                                        value: text,
                                        option: this
                                    };
                            }) );
                        },
                        select: function( event, ui ) {
                             console.log(ui);
                             colorear2(ui.item.option.value);
                            ui.item.option.selected = true;
                            that._trigger( "selected", event, {
                                item: ui.item.option
                            });
                        },
                        change: function( event, ui ) {
                            if ( !ui.item )
                                return removeIfInvalid( this );

                        }
                    })
                    .addClass( "ui-widget ui-widget-content ui-corner-left" );

                input.data( "autocomplete" )._renderItem = function( ul, item ) {
                    return $( "<li>" )
                        .data( "item.autocomplete", item )
                        .append( "<a>" + item.label + "</a>" )
                        .appendTo( ul );
                };

                $( "<a>" )
                    .attr( "tabIndex", -1 )
                    .attr( "title", "Mostrar todos los elementos" )
                    .tooltip()
                    .appendTo( wrapper )
                    .button({
                        icons: {
                            primary: "ui-icon-triangle-1-s"
                        },
                        text: false
                    })
                    .removeClass( "ui-corner-all" )
                    .addClass( "ui-corner-right ui-combobox-toggle" )
                    .click(function() {
                        // close if already visible
                        if ( input.autocomplete( "widget" ).is( ":visible" ) ) {
                            input.autocomplete( "close" );
                            removeIfInvalid( input );
                            return;
                        }

                        // work around a bug (likely same cause as #5265)
                        $( this ).blur();

                        // pass empty string as value to search for, displaying all results
                        input.autocomplete( "search", "" );
                        input.focus();
                    });

                    input
                        .tooltip({
                            position: {
                                of: this.button
                            },
                            tooltipClass: "ui-state-default"
                        });
            },

            destroy: function() {
                this.wrapper.remove();
                this.element.show();
                $.Widget.prototype.destroy.call( this );
            }
        });
    })( jQuery );

    $(function() {
        $( "#destino" ).combobox();
      
    });

}
function autoCompleta(){
(function( $ ) {
        $.widget( "ui.combobox", {
            _create: function() {
                var input,
                    that = this,
                    select = this.element.hide(),
                    selected = select.children( ":selected" ),
                    value = selected.val() ? selected.text() : "",
                    wrapper = this.wrapper = $( "<span>" )
                        .addClass( "ui-combobox" )
                        .insertAfter( select );

                function removeIfInvalid(element) {
                    var value = $( element ).val(),
                        matcher = new RegExp( "^" + $.ui.autocomplete.escapeRegex( value ) + "$", "i" ),
                        valid = false;
                    select.children( "option" ).each(function() {
                        if ( $( this ).text().match( matcher ) ) {
                            this.selected = valid = true;
                            return false;
                        }
                    });
                    if ( !valid ) {
                        // remove invalid value, as it didn't match anything
                        $( element )
                            .val( "" )
                            .attr( "title", value + " didn't match any item" )
                            .tooltip( "open" );
                        select.val( "" );
                        setTimeout(function() {
                            input.tooltip( "close" ).attr( "title", "" );
                        }, 2500 );
                        input.data( "autocomplete" ).term = "";
                        return false;
                    }
                }

                input = $( "<input>" )
                    .appendTo( wrapper )
                    .val( value )
                    .attr( "title", "" )
                    .addClass( "ui-state-default ui-combobox-input" )
                    .autocomplete({
                        delay: 0,
                        minLength: 0,
                        source: function( request, response ) {
                            var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
                            response( select.children( "option" ).map(function() {
                                var text = $( this ).text();
                                if ( this.value && ( !request.term || matcher.test(text) ) )
                                    return {
                                        label: text.replace(
                                            new RegExp(
                                                "(?![^&;]+;)(?!<[^<>]*)(" +
                                                $.ui.autocomplete.escapeRegex(request.term) +
                                                ")(?![^<>]*>)(?![^&;]+;)", "gi"
                                            ), "<strong>$1</strong>" ),
                                        value: text,
                                        option: this
                                    };
                            }) );
                        },
                        select: function( event, ui ) {
                            llenaComboDestino(ui.item.option.value);
                             colorear(ui.item.option.value);
                            ui.item.option.selected = true;
                            that._trigger( "selected", event, {
                                item: ui.item.option
                            });
                        },
                        change: function( event, ui ) {
                            if ( !ui.item )
                                return removeIfInvalid( this );

                        }
                    })
                    .addClass( "ui-widget ui-widget-content ui-corner-left" );

                input.data( "autocomplete" )._renderItem = function( ul, item ) {
                    return $( "<li>" )
                        .data( "item.autocomplete", item )
                        .append( "<a>" + item.label + "</a>" )
                        .appendTo( ul );
                };

                $( "<a>" )
                    .attr( "tabIndex", -1 )
                    .attr( "title", "Mostrar todos los elementos" )
                    .tooltip()
                    .appendTo( wrapper )
                    .button({
                        icons: {
                            primary: "ui-icon-triangle-1-s"
                        },
                        text: false
                    })
                    .removeClass( "ui-corner-all" )
                    .addClass( "ui-corner-right ui-combobox-toggle" )
                    .click(function() {
                        // close if already visible
                        if ( input.autocomplete( "widget" ).is( ":visible" ) ) {
                            input.autocomplete( "close" );
                            removeIfInvalid( input );
                            return;
                        }

                        // work around a bug (likely same cause as #5265)
                        $( this ).blur();

                        // pass empty string as value to search for, displaying all results
                        input.autocomplete( "search", "" );
                        input.focus();
                    });

                    input
                        .tooltip({
                            position: {
                                of: this.button
                            },
                            tooltipClass: "ui-state-default"
                        });
            },

            destroy: function() {
                this.wrapper.remove();
                this.element.show();
                $.Widget.prototype.destroy.call( this );
            }
        });
    })( jQuery );

    $(function() {
        $( "#origen" ).combobox();
      
    });
   
}



window.onload=init;

